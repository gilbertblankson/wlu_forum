<!DOCTYPE html>
<html>

<head>
<title></title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" type="text/css">

<link rel="stylesheet" href="http://test.walulel.co.uk/css/main.css" type="text/css">

</head>



<body>

<h1>Your new Walulel password</h1>
<p>{{$password}}</p>
<p>Please visit the link below to login with your new password.</p>
<p><a class="btn btn-success" target="_blank" href="http://localhost:8000/login">Login with new password</a></p>
    
</body>
</html>